package LL.StockSystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StockSystemApplication {
	public static void main(String[] args) {
		SpringApplication.run(StockSystemApplication.class, args);
	}

}
