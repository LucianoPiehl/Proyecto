package LL.StockSystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StockSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
