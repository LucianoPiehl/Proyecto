package LL.StockSystem.Modelo;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class Usuario {
    @Id
    private Integer id;
    private String name;
    private String nickName;
    private String password;
    private Date fechaNacimiento;
    private Integer edad;
    private byte[] imagen;
}
